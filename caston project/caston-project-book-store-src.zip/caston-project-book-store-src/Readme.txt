Caston Project Book Store Appliaction

these application is completly based on the React,js and google books api

In this appliction elements are divided into 2 those are Pages and Components. The Pages are the 
component that are used as Page in this application, for every Page there is a specific pacth to it.
Based on the path the page should change, which can be implemented using react-router-dom.
Components are the comonent which are used in page component in order to make effective page, which will
Components reuseable.

The state is managed by using redux. In redux file there are 2 javascript file name action.js and reducer.js
the reducer.js contains the initial data and the reducer function which helps to modify the initial data.
and antion.js file contains action function which will be exported and call by other components by
importing that function

futures => serch functionality, user login, cart functionality, favorites functionality, order History

Note: This website is not responsive

for complete/updated website please visit gitHub link where this project will be aploaded

link: https://github.com/Vishnu367?tab=repositories