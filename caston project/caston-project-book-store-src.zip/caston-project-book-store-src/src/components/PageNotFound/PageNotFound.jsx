import React from 'react'

const PageNotFound = () => {
  return (
    <div style={{minHeight: '500px'}}>
      <h1 className='text-center'>Page Not Found!</h1>
    </div>
  )
}

export default PageNotFound
